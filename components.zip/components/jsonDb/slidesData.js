

const slidesData = {
    "slides": [
        {
            "text": "Ob Tür zugefallen",
            "id": 1
        },
        {
            "text": "Schlüssel verloren",
            "id": 2
        },
        {
            "text": "oder Schloss defekt",
            "id": 3
        },
        {
            "text": "Wir kümmern uns darum.",
            "id": 4
        },
        {
            "text": "Darauf geben wir unser Wort",
            "id": 5
        },
        {
            "text": "Kontaktieren Sie uns, wir sind rund um die Uhr für Sie da!",
            "id": 6
        }
    ]
}
