import React from 'react';
import '../../styles/TextSlider.module.css';


const TextSlider = () => {
    return (
        <div className="slider">
            <div className="slide-track">
                <div className="slide">
                    <h3>24/7 Schlüsselnotdienst</h3>    
                </div>
                <div className="slide">
                    <h3>Wir öffnen jede Tür</h3>
                </div>
                <div className="slide">
                    <h3>Wir sind für Sie da</h3>
                </div>
            </div>
        </div>
    );
}

export default TextSlider;
