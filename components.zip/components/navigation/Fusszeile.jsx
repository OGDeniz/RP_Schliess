
export default function Fusszeile() {
    return (
      <div className="d-flex justify-content-center fixed-bottom text-secondary bg-light">
        <h6>
        🔓 RP Schlüsseldienst | 📞 0175 222 222 22 | ⌚ Mo-So: 10:00-22:00
        </h6>        
      </div>
    );
  }
  