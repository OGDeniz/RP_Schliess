import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import styles from '@/styles/navigation.module.css'; 
import { Button } from 'react-bootstrap';
import TextSlider from '../ui/TextSlider';

export default function Navigation() {
    return (
        <nav className={styles.navigation}>
            <div className={styles.navContainer}>
                <div className={styles.leftNav}>
                    <Link href='/'>
                        <Image src='/bilder/img5.png' alt='logo' width={300} height={200} />
                    </Link>
                </div>
                
                <div className={styles.middleNav}>
                    <div className={styles.middleTop}>
                        <h1>Ihr Schlüsselnotdienst | Schnell und jederzeit erreichbar!</h1>
                    </div>
                    <div className={styles.middleBottom}>
                        <TextSlider />
                    </div>
                </div>
                
                <div className={styles.rightNav}>
                    <Link className={`${styles.link} ${styles.btn} `} href="/produkte">
                        Dienstleistungen
                    </Link>

                    <Link className={`${styles.link} ${styles.btn} `} href="/contact">
                        Kontakt
                    </Link>

                    <Link className={`${styles.link} ${styles.btn} `} href="/aboutus">
                        Über uns
                    </Link>
                </div>
            </div>
        </nav>
    );
}